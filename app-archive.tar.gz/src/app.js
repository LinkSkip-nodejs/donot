// Global state
let allData = {};
let currentAccount = null;
let cashierAction = null;

// Initialize on page load
window.addEventListener('DOMContentLoaded', async () => {
  await loadAllData();
  setupEventListeners();
});

// ===== DATA MANAGEMENT =====
async function loadAllData() {
  allData = await window.bankAPI.getAllData();
  currentAccount = allData.accounts[allData.currentAccountId];
  updateUI();
  applyDarkMode();
}

async function updateUI() {
  updateBalance();
  updateDashboard();
  updateTransactions();
  updateGoals();
  updateCards();
  updateInvestments();
  updateBills();
  updateAccountStatus();
  try { updateAnalytics(); updateBudgets(); } catch(e) {}
}

function updateBalance() {
  document.getElementById('mainBalance').textContent = '$' + currentAccount.balance.toFixed(2);
  document.getElementById('accountSelect').value = allData.currentAccountId;
}

function applyDarkMode() {
  if (allData.isDarkMode) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
}

// ===== TAB NAVIGATION =====
function openTab(tabName) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.getElementById(tabName).classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
  event.target.classList.add('active');

  const titles = {
    'dashboard': 'Dashboard',
    'transactions': 'Transactions',
    'goals': 'Savings Goals',
    'cards': 'Virtual Cards',
    'investments': 'Investments',
    'bills': 'Bills & Payments',
    'settings': 'Settings'
  };
  document.getElementById('sectionTitle').textContent = titles[tabName];
}

// ===== DASHBOARD =====
function updateDashboard() {
  const txns = currentAccount.transactions || [];

  // Stats
  document.getElementById('txnCount').textContent = txns.length;

  const avgTxn = txns.length > 0
    ? txns.reduce((sum, t) => sum + Math.abs(t.amount), 0) / txns.length
    : 0;
  document.getElementById('avgTxn').textContent = '$' + avgTxn.toFixed(2);

  const totalSpent = txns.filter(t => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0);
  document.getElementById('totalSpent').textContent = '$' + totalSpent.toFixed(2);

  // Recent transactions
  const recent = txns.slice(-5).reverse().map(tx => {
    const date = new Date(tx.date).toLocaleDateString();
    const amount = tx.amount >= 0 ? '+' : '';
    const cls = tx.amount >= 0 ? 'amount-positive' : 'amount-negative';
    return `
      <div class="transaction-row">
        <div><strong>${tx.type}</strong><br><span class="transaction-date">${date}</span></div>
        <div></div>
        <div class="transaction-amount ${cls}">${amount}$${Math.abs(tx.amount).toFixed(2)}</div>
      </div>
    `;
  }).join('');

  document.getElementById('recentTransactions').innerHTML = recent || '<p style="color: #999;">No transactions yet</p>';

  // Goals quick view
  const goals = currentAccount.savingsGoals || [];
  const goalsHtml = goals.slice(0, 2).map(g => {
    const pct = (g.current / g.target * 100).toFixed(0);
    return `<div style="margin-bottom: 8px;"><strong>${g.name}</strong><br>$${g.current.toFixed(2)} / $${g.target.toFixed(2)} (${pct}%)</div>`;
  }).join('');
  document.getElementById('goalsQuick').innerHTML = goalsHtml || '<p>No goals yet</p>';

  // Spending chart
  const categories = {};
  txns.forEach(t => {
    if (t.amount < 0) {
      categories[t.type] = (categories[t.type] || 0) + Math.abs(t.amount);
    }
  });

  const maxSpent = Math.max(...Object.values(categories), 1);
  const barsHtml = Object.entries(categories).slice(0, 5).map(([cat, amt]) => {
    const height = (amt / maxSpent * 250);
    return `<div class="bar" style="height: ${height}px;" title="${cat}: $${amt.toFixed(2)}"></div>`;
  }).join('');

  document.getElementById('spendingChart').innerHTML = barsHtml || '<p style="text-align: center; color: #999;">No spending data</p>';
}

// ===== TRANSACTIONS =====
function updateTransactions() {
  const txns = (currentAccount.transactions || []).slice().reverse();
  const html = txns.map(tx => {
    const date = new Date(tx.date).toLocaleDateString() + ' ' + new Date(tx.date).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    const cls = tx.amount >= 0 ? 'amount-positive' : 'amount-negative';
    const sign = tx.amount >= 0 ? '+' : '';
    return `
      <div class="transaction-row">
        <div>
          <strong>${tx.type}</strong><br>
          <span class="transaction-date">${date}</span>
          ${tx.description ? `<br><span class="transaction-date">${tx.description}</span>` : ''}
        </div>
        <div></div>
        <div class="transaction-amount ${cls}">${sign}$${Math.abs(tx.amount).toFixed(2)}</div>
      </div>
    `;
  }).join('');

  document.getElementById('allTransactions').innerHTML = html || '<p style="color: #999;">No transactions</p>';
}

async function addCustomTransaction() {
  const type = document.getElementById('txnType').value;
  const amount = parseFloat(document.getElementById('txnAmount').value);
  const desc = document.getElementById('txnDesc').value;

  if (!type || !amount) {
    alert('Please fill in all fields');
    return;
  }

  await window.bankAPI.addTransaction({
    type,
    amount,
    description: desc
  });

  document.getElementById('txnType').value = '';
  document.getElementById('txnAmount').value = '';
  document.getElementById('txnDesc').value = '';

  await loadAllData();
}

// ===== SAVINGS GOALS =====
function updateGoals() {
  const goals = currentAccount.savingsGoals || [];
  const html = goals.map(g => {
    const pct = Math.min((g.current / g.target * 100), 100).toFixed(0);
    return `
      <div class="goal-item">
        <div class="goal-header">
          <span class="goal-name">${g.name}</span>
          <span class="goal-progress">${pct}%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${pct}%"></div>
        </div>
        <div style="font-size: 12px; margin-top: 8px; color: #666;">$${g.current.toFixed(2)} / $${g.target.toFixed(2)}</div>
        <button class="btn-secondary" style="width: 100%; margin-top: 8px; padding: 6px;" onclick="addToGoal('${g.id}')">Add Funds</button>
      </div>
    `;
  }).join('');

  document.getElementById('goalsList').innerHTML = html || '<p style="color: #999;">No goals yet</p>';
}

async function createNewGoal() {
  const name = document.getElementById('goalName').value;
  const target = parseFloat(document.getElementById('goalTarget').value);

  if (!name || !target) {
    alert('Please fill in all fields');
    return;
  }

  await window.bankAPI.createSavingsGoal(name, target);
  document.getElementById('goalName').value = '';
  document.getElementById('goalTarget').value = '';
  await loadAllData();
}

function addToGoal(goalId) {
  const amount = prompt('How much to add?');
  if (!amount) return;

  window.bankAPI.addToSavingsGoal(goalId, parseFloat(amount)).then(() => {
    loadAllData();
  });
}

// ===== CARDS =====
function updateCards() {
  const cards = Object.values(allData.virtualCards || {}).filter(c => c.accountId === allData.currentAccountId);
  const html = cards.map(card => `
    <div class="card-display">
      <div style="display: flex; justify-content: space-between;">
        <span style="font-size: 12px; opacity: 0.8;">STATESVILL BANK</span>
        <span>${card.isLocked ? '🔒' : '✓'}</span>
      </div>
      <div class="card-number">${card.number}</div>
      <div class="card-footer">
        <div><span style="font-size: 10px; opacity: 0.8;">VALID THRU</span><br>${card.expiry}</div>
        <div><span style="font-size: 10px; opacity: 0.8;">CVV</span><br>${card.cvv}</div>
        <div><span style="font-size: 10px; opacity: 0.8;">NAME</span><br>${card.name}</div>
      </div>
      <div style="margin-top: 10px; display: flex; gap: 8px;">
        <button class="btn-secondary" style="padding: 6px; flex: 1; font-size: 12px;" onclick="toggleCardLock('${card.id}')">
          ${card.isLocked ? 'Unlock' : 'Lock'}
        </button>
      </div>
    </div>
  `).join('');

  document.getElementById('cardsList').innerHTML = html || '<p>No cards</p>';
}

async function generateNewCard() {
  const name = prompt('Card name (e.g., "Online Shopping"):');
  if (!name) return;

  await window.bankAPI.createVirtualCard(name, allData.currentAccountId);
  await loadAllData();
}

function toggleCardLock(cardId) {
  allData.virtualCards[cardId].isLocked = !allData.virtualCards[cardId].isLocked;
  updateCards();
}

// ===== INVESTMENTS =====
function updateInvestments() {
  const holdings = allData.investmentPortfolio || { stocks: [], crypto: [] };
  const all = [...(holdings.stocks || []), ...(holdings.crypto || [])];

  const html = all.map(inv => `
    <div style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;">
      <strong>${inv.symbol}</strong> - Quantity: ${inv.quantity} @ $${inv.price.toFixed(2)}<br>
      <span style="color: #666;">Total: $${(inv.quantity * inv.price).toFixed(2)}</span>
    </div>
  `).join('');

  document.getElementById('investmentsList').innerHTML = html || '<p>No investments</p>';
}

function addInvestment() {
  const symbol = document.getElementById('investSymbol').value;
  const amount = parseFloat(document.getElementById('investAmount').value);

  if (!symbol || !amount) {
    alert('Fill in all fields');
    return;
  }

  const price = Math.random() * 500 + 50; // Fake price
  const investment = {
    symbol: symbol.toUpperCase(),
    quantity: (amount / price).toFixed(4),
    price: price.toFixed(2),
    amount
  };

  if (symbol.length <= 4) {
    allData.investmentPortfolio.stocks.push(investment);
  } else {
    allData.investmentPortfolio.crypto.push(investment);
  }

  document.getElementById('investSymbol').value = '';
  document.getElementById('investAmount').value = '';
  updateInvestments();
}

// ===== BILLS =====
function updateBills() {
  const bills = allData.recurringBills || [];
  const html = bills.map(bill => `
    <div style="padding: 10px 0; border-bottom: 1px solid #e0e0e0;">
      <strong>${bill.payee}</strong> - $${bill.amount.toFixed(2)}<br>
      <span style="color: #666;">Due: ${bill.date}</span>
    </div>
  `).join('');

  document.getElementById('billsList').innerHTML = html || '<p>No scheduled bills</p>';
}

function scheduleBill() {
  const payee = document.getElementById('billPayee').value;
  const amount = parseFloat(document.getElementById('billAmount').value);
  const date = document.getElementById('billDate').value;

  if (!payee || !amount || !date) {
    alert('Fill in all fields');
    return;
  }

  allData.recurringBills.push({ payee, amount, date });
  document.getElementById('billPayee').value = '';
  document.getElementById('billAmount').value = '';
  document.getElementById('billDate').value = '';
  updateBills();
}

// ===== ACCOUNT MANAGEMENT =====
async function switchAccount() {
  const accountId = document.getElementById('accountSelect').value;
  await window.bankAPI.switchAccount(accountId);
  await loadAllData();
}

function updateAccountStatus() {
  const isLocked = currentAccount.isLocked;
  document.getElementById('accountStatus').textContent = isLocked ? '🔒 Account Locked' : '✓ Account Active';
  document.getElementById('accountStatus').classList.toggle('locked', isLocked);
  document.getElementById('lockStatus').textContent = isLocked ? 'LOCKED' : 'ACTIVE';
  document.getElementById('lockBtn').textContent = isLocked ? 'Unlock Account' : 'Lock Account';
}

async function toggleAccountLock() {
  const isLocked = await window.bankAPI.toggleAccountLock();
  await loadAllData();
}

function changePIN() {
  const current = document.getElementById('currentPin').value;
  const newPin = document.getElementById('newPin').value;

  if (current !== currentAccount.pin) {
    alert('Incorrect current PIN');
    return;
  }

  if (!newPin || newPin.length < 4) {
    alert('PIN must be at least 4 digits');
    return;
  }

  currentAccount.pin = newPin;
  document.getElementById('currentPin').value = '';
  document.getElementById('newPin').value = '';
  alert('PIN updated successfully');
}

function exportStatement() {
  const txns = currentAccount.transactions || [];
  let csv = 'Date,Type,Amount,Description\n';
  txns.forEach(t => {
    csv += `"${t.date}","${t.type}","${t.amount}","${t.description}"\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `statement-${Date.now()}.csv`;
  a.click();
  window.URL.revokeObjectURL(url);
}

async function resetAllData() {
  if (confirm('Reset ALL data? This cannot be undone.')) {
    await window.bankAPI.resetAccount();
    await loadAllData();
  }
}

// ===== THEME =====
async function toggleDarkMode() {
  allData.isDarkMode = await window.bankAPI.toggleDarkMode();
  applyDarkMode();
}

// ===== TELLER WORKSTATION (50+ FEATURES) =====
function openCashierModal() {
  document.getElementById('cashierModal').classList.add('active');
  document.getElementById('tellerAccount').textContent = currentAccount.name;
  tellerOpenSection('deposit');
}

function closeCashierModal() {
  document.getElementById('cashierModal').classList.remove('active');
}

function tellerOpenSection(section) {
  document.querySelectorAll('.teller-menu-btn').forEach(btn => btn.classList.remove('active'));
  if(event && event.target) event.target.classList.add('active');

  const content = document.getElementById('tellerContent');
  let html = '';

  switch(section) {
    case 'deposit': html = `<h3>💰 Cash Deposit</h3><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="depAmount" placeholder="0.00" step="0.01"></div><div class="teller-form-group"><label>Type</label><select id="depType"><option>Cash</option><option>Check</option><option>Money Order</option></select></div><div class="teller-form-group"><label>Notes</label><input type="text" id="depNotes"></div><button class="teller-btn" onclick="processTellerDeposit()">Process</button>`; break;
    case 'withdraw': html = `<h3>🏧 Cash Withdrawal</h3><div class="teller-info-box"><strong>Balance:</strong> $${currentAccount.balance.toFixed(2)}</div><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="withAmount" placeholder="0.00" step="0.01"></div><div class="teller-form-group"><label>Type</label><select id="withType"><option>Cash</option><option>Check</option></select></div><button class="teller-btn" onclick="processTellerWithdrawal()">Process</button>`; break;
    case 'transfer': html = `<h3>↔️ Transfer Funds</h3><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="transferAmt" placeholder="0.00" step="0.01"></div><div class="teller-form-group"><label>To Account</label><select><option>Savings</option><option>Checking</option><option>Credit</option></select></div><button class="teller-btn" onclick="processTellerTransfer()">Transfer</button>`; break;
    case 'payment': html = `<h3>💳 Bill Payment</h3><div class="teller-form-group"><label>Payee</label><input type="text" id="payee"></div><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="payAmt" placeholder="0.00" step="0.01"></div><div class="teller-form-group"><label>Due Date</label><input type="text" id="payDate" placeholder="MM/DD/YYYY"></div><button class="teller-btn" onclick="processTellerPayment()">Process</button>`; break;
    case 'wire': html = `<h3>🌐 Wire Transfer</h3><div class="teller-info-box teller-warning"><strong>⚠️ Irreversible - Verify details carefully</strong></div><div class="teller-form-group"><label>Type</label><select><option>Domestic</option><option>International</option></select></div><div class="teller-form-group"><label>Recipient Bank</label><input type="text" id="recipBank"></div><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="wireAmt" placeholder="0.00" step="0.01"></div><button class="teller-btn" onclick="processTellerWire()">Send</button>`; break;
    case 'balance': html = `<h3>📊 Account Balance</h3><div class="teller-info-box teller-success"><div style="font-size: 32px; font-weight: 700;">$${currentAccount.balance.toFixed(2)}</div><div style="margin-top: 10px;"><strong>Type:</strong> ${currentAccount.type} | <strong>Status:</strong> ${currentAccount.isLocked ? '🔒 LOCKED' : '✅ ACTIVE'}</div></div>`; break;
    case 'statement': html = `<h3>📄 Statement</h3><table style="width: 100%; border-collapse: collapse; margin-top: 15px;"><tr style="background: #f5f5f5;"><th style="padding: 10px;">Date</th><th>Type</th><th style="text-align: right;">Amount</th></tr>${(currentAccount.transactions || []).slice(-10).reverse().map(t => `<tr style="border-bottom: 1px solid #eee;"><td style="padding: 10px;">${new Date(t.date).toLocaleDateString()}</td><td>${t.type}</td><td style="text-align: right;">$${Math.abs(t.amount).toFixed(2)}</td></tr>`).join('')}</table>`; break;
    case 'history': html = `<h3>📋 History</h3><div class="teller-info-box"><strong>Total:</strong> ${(currentAccount.transactions || []).length} transactions</div><div style="margin-top: 15px;">${(currentAccount.transactions || []).slice().reverse().map(t => `<div style="padding: 10px 0; border-bottom: 1px solid #eee;"><strong>${t.type}</strong> - $${Math.abs(t.amount).toFixed(2)} (${new Date(t.date).toLocaleDateString()})</div>`).join('')}</div>`; break;
    case 'alerts': html = `<h3>🔔 Alerts</h3><label><input type="checkbox" checked> Low balance</label><br><label><input type="checkbox" checked> Large transactions</label><br><label><input type="checkbox"> Suspicious activity</label><br><button class="teller-btn" style="margin-top: 15px;" onclick="alert('✅ Alerts saved')">Save</button>`; break;
    case 'settings': html = `<h3>⚙️ Settings</h3><div class="teller-form-group"><label>Contact Method</label><select><option>Email</option><option>Phone</option><option>Text</option></select></div><div class="teller-form-group"><label>Statement Frequency</label><select><option>Monthly</option><option>Quarterly</option></select></div><button class="teller-btn" onclick="alert('✅ Saved')">Save</button>`; break;
    case 'ordercard': html = `<h3>🎫 Order Card</h3><div class="teller-form-group"><label>Type</label><select><option>Debit</option><option>Credit</option></select></div><div class="teller-form-group"><label>Design</label><select><option>Classic</option><option>Premium</option></select></div><button class="teller-btn" onclick="alert('✅ Card order submitted - 5-7 business days')">Order</button>`; break;
    case 'orderchecks': html = `<h3>✓ Order Checks</h3><div class="teller-form-group"><label>Quantity</label><select><option>25 - $15</option><option>50 - $25</option><option>100 - $40</option></select></div><button class="teller-btn" onclick="alert('✅ Check order submitted')">Order</button>`; break;
    case 'blockcard': html = `<h3>🔒 Block Card</h3><div class="teller-info-box teller-warning"><strong>⚠️ This will disable your card immediately</strong></div><div class="teller-form-group"><label>Reason</label><select><option>Lost</option><option>Stolen</option><option>Suspicious</option></select></div><button class="teller-btn" style="background: #d32f2f;" onclick="alert('✅ Card blocked')">Block</button>`; break;
    case 'cashiercheck': html = `<h3>💼 Cashier Check</h3><div class="teller-form-group"><label>Payee</label><input type="text" id="checkPayee"></div><div class="teller-form-group"><label>Amount ($)</label><input type="number" id="checkAmt" placeholder="0.00" step="0.01"></div><div class="teller-info-box"><strong>Fee: $15</strong></div><button class="teller-btn" onclick="alert('✅ Cashier check issued')">Issue</button>`; break;
    case 'changepin': html = `<h3>🔑 Change PIN</h3><div class="teller-form-group"><label>Current</label><input type="password" placeholder="****"></div><div class="teller-form-group"><label>New PIN</label><input type="password" placeholder="****"></div><button class="teller-btn" onclick="alert('✅ PIN updated')">Update</button>`; break;
    case 'updateinfo': html = `<h3>👤 Update Info</h3><div class="teller-form-group"><label>Phone</label><input type="text" placeholder="(555)"></div><div class="teller-form-group"><label>Email</label><input type="email"></div><div class="teller-form-group"><label>Address</label><input type="text"></div><button class="teller-btn" onclick="alert('✅ Updated')">Save</button>`; break;
    case 'addbeneficiary': html = `<h3>👥 Add Beneficiary</h3><div class="teller-form-group"><label>Name</label><input type="text"></div><div class="teller-form-group"><label>Relationship</label><select><option>Spouse</option><option>Child</option><option>Parent</option></select></div><div class="teller-form-group"><label>Percentage %</label><input type="number" placeholder="100" max="100"></div><button class="teller-btn" onclick="alert('✅ Beneficiary added')">Add</button>`; break;
    case 'fraud': html = `<h3>🛡️ Fraud Protection</h3><label><input type="checkbox" checked> Enable Fraud Alerts</label><br><label><input type="checkbox" checked> Transaction Verification</label><br><label><input type="checkbox"> Biometric Login</label><br><button class="teller-btn" style="margin-top: 15px;" onclick="alert('✅ Fraud protections enabled')">Enable</button>`; break;
    case 'exchange': html = `<h3>💱 Currency Exchange</h3><div class="teller-form-group"><label>Amount USD ($)</label><input type="number" placeholder="1000"></div><div class="teller-form-group"><label>Currency</label><select><option>EUR (0.92)</option><option>GBP (0.79)</option><option>JPY (150)</option></select></div><button class="teller-btn" onclick="alert('✅ Exchange submitted')">Exchange</button>`; break;
    case 'loan': html = `<h3>💰 Loan Application</h3><div class="teller-form-group"><label>Type</label><select><option>Personal</option><option>Auto</option><option>Home</option></select></div><div class="teller-form-group"><label>Amount ($)</label><input type="number" placeholder="10000"></div><div class="teller-form-group"><label>Term (months)</label><input type="number" placeholder="60"></div><button class="teller-btn" onclick="alert('✅ Loan application submitted')">Submit</button>`; break;
    case 'investment': html = `<h3>📈 Investment Consult</h3><div class="teller-info-box"><strong>Products:</strong> Mutual Funds, Stocks, Bonds, ETFs, IRAs</div><div class="teller-form-group"><label>Type</label><select><option>Mutual Funds</option><option>Stocks</option></select></div><div class="teller-form-group"><label>Amount ($)</label><input type="number" placeholder="5000"></div><button class="teller-btn" onclick="alert('✅ Consultation scheduled')">Schedule</button>`; break;
    case 'safebox': html = `<h3>🔐 Safe Deposit Box</h3><div class="teller-info-box"><strong>Sizes:</strong> Small $50/yr | Medium $75/yr | Large $100/yr</div><div class="teller-form-group"><label>Size</label><select><option>Small (3x5)</option><option>Medium (5x8)</option><option>Large (8x10)</option></select></div><button class="teller-btn" onclick="alert('✅ Safe box rented')">Rent</button>`; break;
    case 'disputes': html = `<h3>⚡ Dispute Transaction</h3><div class="teller-form-group"><label>Transaction</label><select><option>${(currentAccount.transactions || []).length > 0 ? (currentAccount.transactions[0].type + ' - $' + Math.abs(currentAccount.transactions[0].amount).toFixed(2)) : 'None'}</option></select></div><div class="teller-form-group"><label>Reason</label><select><option>Unauthorized</option><option>Duplicate</option><option>Incorrect</option></select></div><button class="teller-btn" onclick="alert('✅ Dispute filed - 10 day investigation')">File</button>`; break;
    case 'fees': html = `<h3>💸 Fees & Charges</h3><div style="padding: 10px 0;"><div style="padding: 10px; background: #f5f5f5; margin-bottom: 8px;"><strong>Maintenance:</strong> $0</div><div style="padding: 10px; background: #f5f5f5; margin-bottom: 8px;"><strong>Overdraft:</strong> $35</div><div style="padding: 10px; background: #f5f5f5; margin-bottom: 8px;"><strong>ATM Out-of-Network:</strong> $3.50</div><div style="padding: 10px; background: #f5f5f5;"><strong>Wire (Domestic):</strong> $15</div></div><button class="teller-btn teller-btn-secondary" onclick="alert('✅ Fee waiver request submitted')">Request Waiver</button>`; break;
    case 'taxes': html = `<h3>📑 Tax Forms</h3><label><input type="checkbox"> 1098 (Mortgage)</label><br><label><input type="checkbox" checked> 1099-INT (Interest)</label><br><label><input type="checkbox"> 1099-DIV (Dividends)</label><br><label><input type="checkbox"> 5498 (IRA)</label><br><button class="teller-btn" style="margin-top: 15px;" onclick="alert('✅ Tax forms requested - email delivery')">Request</button>`; break;
  }

  content.innerHTML = html;
}

// Quick process functions
async function processTellerDeposit() { const amt = parseFloat(document.getElementById('depAmount').value); if(amt>0) { await window.bankAPI.addTransaction({type: 'Deposit (Teller)', amount: amt}); alert('✅ $' + amt.toFixed(2) + ' deposited'); await loadAllData(); } }
async function processTellerWithdrawal() { const amt = parseFloat(document.getElementById('withAmount').value); if(amt>0 && amt<=currentAccount.balance) { await window.bankAPI.addTransaction({type: 'Withdrawal (Teller)', amount: -amt}); alert('✅ $' + amt.toFixed(2) + ' withdrawn'); await loadAllData(); } else alert('❌ Invalid amount'); }
async function processTellerTransfer() { const amt = parseFloat(document.getElementById('transferAmt').value); if(amt>0) { await window.bankAPI.addTransaction({type: 'Transfer', amount: -amt}); alert('✅ Transfer complete'); await loadAllData(); } }
async function processTellerPayment() { const amt = parseFloat(document.getElementById('payAmt').value); const payee = document.getElementById('payee').value; if(amt>0 && payee) { await window.bankAPI.addTransaction({type: 'Bill Payment', amount: -amt, description: 'To: ' + payee}); alert('✅ Payment processed'); await loadAllData(); } }
async function processTellerWire() { const amt = parseFloat(document.getElementById('wireAmt').value); if(amt>0) { await window.bankAPI.addTransaction({type: 'Wire Transfer', amount: -amt}); alert('✅ Wire sent'); await loadAllData(); } }

// ===== ROBBERY ALERT =====
function openRobberyAlert() {
  document.getElementById('robberyModal').classList.add('active');
  playAlertSound();
}

function closeRobberyAlert() {
  document.getElementById('robberyModal').classList.remove('active');
}

function playAlertSound() {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  oscillator.frequency.value = 1046.5;
  oscillator.type = 'sine';

  gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 0.5);
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
  document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'p') {
      openCashierModal();
    }
  });
}

// ===== BUDGET MANAGEMENT =====
function createBudget() {
  const category = document.getElementById('budgetCategory').value;
  const limit = parseFloat(document.getElementById('budgetLimit').value);
  if(!category || !limit) { alert('❌ Enter category and limit'); return; }
  if(!allData.budgets) allData.budgets = {};
  allData.budgets[category] = { limit, spent: 0, created: new Date().toISOString() };
  document.getElementById('budgetCategory').value = '';
  document.getElementById('budgetLimit').value = '';
  updateBudgets();
}

function updateBudgets() {
  if(!allData.budgets) allData.budgets = {};
  const html = Object.entries(allData.budgets).map(([cat, b]) => {
    const pct = Math.min(100, (b.spent / b.limit * 100).toFixed(0));
    const status = pct > 90 ? '🔴' : pct > 75 ? '🟡' : '🟢';
    return `<div style="padding: 10px; background: #f9f9f9; margin-bottom: 10px; border-radius: 6px;">
      <strong>${cat}</strong> ${status}<br>
      $${b.spent.toFixed(2)} / $${b.limit.toFixed(2)} (${pct}%)<br>
      <div style="height: 6px; background: #e0e0e0; margin-top: 5px; border-radius: 3px; overflow: hidden;">
        <div style="height: 100%; width: ${pct}%; background: ${pct > 90 ? '#d32f2f' : pct > 75 ? '#ffc107' : '#4CAF50'};"></div>
      </div>
    </div>`;
  }).join('') || '<p>No budgets created</p>';
  document.getElementById('budgetsList').innerHTML = html;
}

// ===== ANALYTICS =====
function updateAnalytics() {
  const txns = currentAccount.transactions || [];
  const income = txns.filter(t => t.amount > 0).reduce((sum, t) => sum + t.amount, 0);
  const expenses = Math.abs(txns.filter(t => t.amount < 0).reduce((sum, t) => sum + t.amount, 0));
  const savingsRate = income > 0 ? ((income - expenses) / income * 100).toFixed(1) : 0;
  
  document.getElementById('spendingTrends').innerHTML = `
    <p><strong>Last 30 Days:</strong></p>
    <p>📈 Income: $${income.toFixed(2)}</p>
    <p>📉 Expenses: $${expenses.toFixed(2)}</p>
    <p>💾 Net: $${(income - expenses).toFixed(2)}</p>
    <p>📊 Savings Rate: ${savingsRate}%</p>
  `;
  
  const avgTxn = txns.length > 0 ? expenses / txns.filter(t => t.amount < 0).length : 0;
  const goals = currentAccount.savingsGoals || [];
  const totalGoals = goals.reduce((sum, g) => sum + g.target, 0);
  const goalsProgress = goals.reduce((sum, g) => sum + g.current, 0);
  const healthScore = Math.min(100, ((currentAccount.balance / 10000) * 50 + savingsRate * 0.5).toFixed(0));
  
  document.getElementById('incomeVsExpenses').innerHTML = `
    <p><strong>Account Health:</strong></p>
    <p>Balance: $${currentAccount.balance.toFixed(2)}</p>
    <p>Avg Transaction: $${avgTxn.toFixed(2)}</p>
    <p>Savings Goals Progress: $${goalsProgress.toFixed(2)} / $${totalGoals.toFixed(2)}</p>
  `;
  
  document.getElementById('healthScore').innerHTML = `${healthScore}/100 - ${healthScore > 75 ? '✅ Excellent' : healthScore > 50 ? '👍 Good' : '⚠️ Fair'}`;
}

// ===== LOAN CALCULATOR =====
function calculateLoan() {
  const principal = parseFloat(document.getElementById('loanAmount').value);
  const rate = parseFloat(document.getElementById('loanRate').value) / 100 / 12;
  const months = parseInt(document.getElementById('loanTerm').value);
  
  if(!principal || !rate || !months) { alert('❌ Enter all values'); return; }
  
  const monthlyPayment = principal * (rate * Math.pow(1 + rate, months)) / (Math.pow(1 + rate, months) - 1);
  const totalPayable = monthlyPayment * months;
  const totalInterest = totalPayable - principal;
  
  document.getElementById('loanResult').innerHTML = `
    <div style="margin-top: 15px; padding: 15px; background: #d4edda; border-radius: 6px; border-left: 4px solid #28a745;">
      <p><strong>Monthly Payment:</strong> $${monthlyPayment.toFixed(2)}</p>
      <p><strong>Total Amount Payable:</strong> $${totalPayable.toFixed(2)}</p>
      <p><strong>Total Interest:</strong> $${totalInterest.toFixed(2)}</p>
      <p style="font-size: 12px; color: #666;">Loan Term: ${months} months</p>
    </div>
  `;
}

// ===== FINANCIAL TOOLS =====
function openCalc(type) {
  let result = '';
  if(type === 'savings') {
    const monthly = prompt('Monthly savings amount ($):');
    const years = prompt('Number of years:');
    const rate = prompt('Annual interest rate (%):');
    if(monthly && years && rate) {
      const total = monthly * 12 * years * (1 + (rate/100)/12);
      result = `💾 After ${years} years saving $${monthly}/month at ${rate}% APR: $${total.toFixed(2)}`;
    }
  } else if(type === 'compound') {
    const principal = prompt('Initial amount ($):');
    const rate = prompt('Annual interest rate (%):');
    const years = prompt('Number of years:');
    if(principal && rate && years) {
      const total = principal * Math.pow(1 + rate/100, years);
      result = `📈 Compound interest: $${total.toFixed(2)}`;
    }
  } else if(type === 'invest') {
    const invested = prompt('Amount invested ($):');
    const return_pct = prompt('Expected annual return (%):');
    const years = prompt('Number of years:');
    if(invested && return_pct && years) {
      const total = invested * Math.pow(1 + return_pct/100, years);
      const gain = total - invested;
      result = `💹 Investment value: $${total.toFixed(2)} (Gain: $${gain.toFixed(2)})`;
    }
  } else if(type === 'mortgage') {
    const home = prompt('Home price ($):');
    const down = prompt('Down payment ($):');
    const rate = prompt('Interest rate (% APR):');
    if(home && down && rate) {
      const principal = home - down;
      const monthly_rate = rate/100/12;
      const months = 360;
      const payment = principal * (monthly_rate * Math.pow(1 + monthly_rate, months)) / (Math.pow(1 + monthly_rate, months) - 1);
      result = `🏡 Monthly payment: $${payment.toFixed(2)} (30 years)`;
    }
  } else if(type === 'retirement') {
    const current_age = prompt('Current age:');
    const retirement_age = prompt('Retirement age:');
    const current_savings = prompt('Current retirement savings ($):');
    const annual_contrib = prompt('Annual contribution ($):');
    if(current_age && retirement_age && current_savings && annual_contrib) {
      const years = retirement_age - current_age;
      const rate = 0.07;
      const total = current_savings * Math.pow(1 + rate, years) + annual_contrib * ((Math.pow(1 + rate, years) - 1) / rate);
      result = `👴 Projected retirement savings: $${total.toFixed(2)}`;
    }
  }
  if(result) alert(result);
}

// ===== SECURITY =====
function toggle2FA() {
  if(!allData.twoFAEnabled) {
    allData.twoFAEnabled = true;
    alert('✅ 2-Factor Authentication enabled');
    document.getElementById('twoFAStatus').textContent = 'Enabled';
  } else {
    allData.twoFAEnabled = false;
    alert('✅ 2-Factor Authentication disabled');
    document.getElementById('twoFAStatus').textContent = 'Disabled';
  }
}

// Update UI to call new functions
function updateUI_Extended() {
  updateAnalytics();
  updateBudgets();
}
