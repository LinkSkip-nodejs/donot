const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

const DATA_FILE = path.join(os.homedir(), '.fakebank', 'data.json');
let mainWindow;

const getInitialData = () => ({
  currentAccountId: 'checking-001',
  isDarkMode: false,
  accounts: {
    'checking-001': { id: 'checking-001', name: 'Checking Account', type: 'checking', balance: 5000, pin: '1234', isLocked: false, transactions: [], savingsGoals: [] },
    'savings-001': { id: 'savings-001', name: 'Savings Account', type: 'savings', balance: 10000, pin: '1234', isLocked: false, transactions: [], savingsGoals: [{ id: 'goal1', name: 'Vacation', target: 5000, current: 2500 }, { id: 'goal2', name: 'Emergency Fund', target: 10000, current: 8000 }] },
    'credit-001': { id: 'credit-001', name: 'Credit Card', type: 'credit', balance: -1500, pin: '1234', isLocked: false, transactions: [], savingsGoals: [], creditLimit: 10000 }
  },
  virtualCards: { 'card-001': { id: 'card-001', name: 'Primary Card', number: '4532 ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0') + ' ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0') + ' ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0'), expiry: new Date(Date.now() + 365*24*60*60*1000).toLocaleDateString('en-US', {year: '2-digit', month: '2-digit'}), cvv: Math.floor(Math.random() * 900) + 100, isLocked: false, spendingLimit: 500, accountId: 'checking-001' } },
  recurringBills: [],
  alerts: [],
  investmentPortfolio: { stocks: [], crypto: [] }
});

(() => {
  const dataDir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify(getInitialData(), null, 2));
})();

app.on('ready', () => {
  ipcMain.handle('bank-api:getAllData', async () => { try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); } catch (err) { return null; } });
  ipcMain.handle('bank-api:getCurrentAccount', async () => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); return data.accounts[data.currentAccountId]; } catch (err) { return null; } });
  ipcMain.handle('bank-api:switchAccount', async (event, accountId) => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); data.currentAccountId = accountId; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return data.accounts[accountId]; } catch (err) { return null; } });
  ipcMain.handle('bank-api:addTransaction', async (event, transaction) => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); const accountId = data.currentAccountId; transaction.date = new Date().toISOString(); transaction.id = 'txn_' + Date.now(); data.accounts[accountId].transactions.push(transaction); data.accounts[accountId].balance += transaction.amount; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return data.accounts[accountId]; } catch (err) { return null; } });
  ipcMain.handle('bank-api:createSavingsGoal', async (event, name, target) => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); const accountId = data.currentAccountId; const goal = { id: 'goal_' + Date.now(), name, target, current: 0 }; data.accounts[accountId].savingsGoals.push(goal); fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return goal; } catch (err) { return null; } });
  ipcMain.handle('bank-api:addToSavingsGoal', async (event, goalId, amount) => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); const accountId = data.currentAccountId; const goal = data.accounts[accountId].savingsGoals.find(g => g.id === goalId); if (goal) { goal.current += amount; data.accounts[accountId].balance -= amount; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); } return goal; } catch (err) { return null; } });
  ipcMain.handle('bank-api:createVirtualCard', async (event, name, accountId) => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); const card = { id: 'card_' + Date.now(), name, number: '4532 ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0') + ' ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0') + ' ' + Math.floor(Math.random() * 10000).toString().padStart(4, '0'), expiry: new Date(Date.now() + 365*24*60*60*1000).toLocaleDateString('en-US', {year: '2-digit', month: '2-digit'}), cvv: Math.floor(Math.random() * 900) + 100, isLocked: false, spendingLimit: 500, accountId }; data.virtualCards[card.id] = card; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return card; } catch (err) { return null; } });
  ipcMain.handle('bank-api:toggleDarkMode', async () => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); data.isDarkMode = !data.isDarkMode; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return data.isDarkMode; } catch (err) { return null; } });
  ipcMain.handle('bank-api:toggleAccountLock', async () => { try { const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8')); const accountId = data.currentAccountId; data.accounts[accountId].isLocked = !data.accounts[accountId].isLocked; fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2)); return data.accounts[accountId].isLocked; } catch (err) { return null; } });
  ipcMain.handle('bank-api:resetAccount', async () => { try { const initialData = getInitialData(); fs.writeFileSync(DATA_FILE, JSON.stringify(initialData, null, 2)); return initialData; } catch (err) { return null; } });

  mainWindow = new BrowserWindow({ width: 1000, height: 700, webPreferences: { preload: path.join(__dirname, 'preload.js'), nodeIntegration: false, contextIsolation: true } });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (mainWindow === null) { mainWindow = new BrowserWindow({ width: 1000, height: 700, webPreferences: { preload: path.join(__dirname, 'preload.js'), nodeIntegration: false, contextIsolation: true } }); mainWindow.loadFile(path.join(__dirname, 'index.html')); } });
